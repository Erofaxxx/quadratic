var searchData=
[
  ['count_5fsolutions_0',['count_solutions',['../func_8hpp.html#af6e725f34d8bb4801fe235434f55a4af',1,'func.hpp']]]
];
