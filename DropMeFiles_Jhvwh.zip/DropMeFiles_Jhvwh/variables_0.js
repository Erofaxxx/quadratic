var searchData=
[
  ['a_0',['a',['../structcoeff.html#a1031d0e0a97a340abfe0a6ab9e831045',1,'coeff']]]
];
