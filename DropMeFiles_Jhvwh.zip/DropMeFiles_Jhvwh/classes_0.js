var searchData=
[
  ['coeff_0',['coeff',['../structcoeff.html',1,'']]]
];
