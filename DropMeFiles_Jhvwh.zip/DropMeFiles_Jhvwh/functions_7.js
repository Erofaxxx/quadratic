var searchData=
[
  ['usual_5fquadratic_0',['usual_quadratic',['../func_8hpp.html#a17560d47e44e98a395518a5f4bd5da79',1,'func.hpp']]]
];
