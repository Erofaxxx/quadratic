var searchData=
[
  ['b_0',['b',['../structcoeff.html#a1510a66dacf9cf3586de5fc89ae2a073',1,'coeff']]]
];
