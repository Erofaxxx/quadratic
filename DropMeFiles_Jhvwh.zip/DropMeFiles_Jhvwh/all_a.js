var searchData=
[
  ['q_0',['q',['../structout.html#a5b5e3f03e443adea974601f295136638',1,'out']]],
  ['quadratic_1',['quadratic',['../func_8hpp.html#a149f8de056f797e77c5cfd933f9c00f7',1,'func.hpp']]]
];
