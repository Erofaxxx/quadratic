var searchData=
[
  ['a_0',['a',['../structcoeff.html#a1031d0e0a97a340abfe0a6ab9e831045',1,'coeff']]],
  ['all_5fnumbers_1',['ALL_NUMBERS',['../func_8hpp.html#af6e725f34d8bb4801fe235434f55a4afaf7f8b319272d5d601ace12f50f09696d',1,'func.hpp']]]
];
